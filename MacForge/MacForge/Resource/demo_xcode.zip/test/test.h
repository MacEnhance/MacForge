//
//  test.h
//  test
//
//  Created by Wolfgang Baird on 7/8/18.
//Copyright © 2018 test. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface test : NSObject

+ (instancetype)sharedInstance;

@end
