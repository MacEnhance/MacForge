//
//  test.m
//  test
//
//  Created by Wolfgang Baird on 7/8/18.
//Copyright © 2018 test. All rights reserved.
//

#import "test.h"

// Interface

@interface test()
@end

@interface testTTWindow : NSWindow
@end

// Implementations

@implementation test

// @return the single static instance of the plugin object
+ (instancetype)sharedInstance {
    static test *plugin = nil;
    @synchronized(self) {
        if (!plugin) {
            plugin = [[self alloc] init];
        }
    }
    return plugin;
}

// Swizzle
- (void)swizzleClasses {
    ZKSwizzle(testTTWindow, NSWindow);
}

// Log that we loaded
- (void)sayHello {
    NSUInteger osx_ver = NSProcessInfo.processInfo.operatingSystemVersion.minorVersion;
    NSLog(@"%@ loaded into %@ on macOS 10.%ld", [self class], [[NSBundle mainBundle] bundleIdentifier], (long)osx_ver);
}

// A special method called by MacPlus once the application has started and all classes are initialized.
+ (void)load {
    test *plugin = [test sharedInstance];
    [plugin sayHello];
    [plugin swizzleClasses];
}

@end

@implementation testTTWindow

- (void)display {
    ZKOrig(void);
    NSLog(@"Hooked into %@ : %s : %d", self.className, __PRETTY_FUNCTION__, __LINE__);
}

@end
